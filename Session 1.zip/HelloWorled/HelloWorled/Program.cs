﻿namespace HelloWorld
{
    class HelloWorld
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello world");
        }
    }
}